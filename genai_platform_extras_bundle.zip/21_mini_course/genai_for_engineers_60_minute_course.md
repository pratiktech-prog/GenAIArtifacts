# GenAI for Engineers in 60 Minutes - Mini Course Outline

Module 1 (10 min) - What is GenAI?
- Intuition, strengths, limitations
- Why it matters for engineering

Module 2 (15 min) - Everyday Workflows
- Code generation and refactoring
- Test creation
- Documentation and code comprehension

Module 3 (15 min) - Using the Platform
- MCP-powered context in IDEs
- AI Gateway and why routing matters
- RAG examples for internal docs

Module 4 (10 min) - Safety and Governance
- What not to paste into prompts
- How we log and monitor usage
- Escalation paths and contacts

Module 5 (10 min) - Hands-on Exercise
- Take a real ticket and solve it with GenAI tools
- Share learnings with peers
