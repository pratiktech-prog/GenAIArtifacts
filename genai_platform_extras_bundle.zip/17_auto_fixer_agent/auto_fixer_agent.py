from typing import Tuple

def run_tests(code: str) -> Tuple[bool, str]:
    if "TODO" in code:
        return False, "Found TODO marker - tests failing."
    return True, "All tests passed (simulated)."

def simple_genai_fix(code: str, log: str) -> str:
    if "TODO" in code:
        return code.replace("TODO", "FIXED")
    return code

def auto_fix_loop(initial_code: str, max_iterations: int = 3) -> str:
    code = initial_code
    for i in range(max_iterations):
        ok, log = run_tests(code)
        if ok:
            print(f"Iteration {i}: tests passed.")
            return code
        print(f"Iteration {i}: tests failed -> {log}")
        code = simple_genai_fix(code, log)
    return code

if __name__ == "__main__":
    sample = "def add(a, b):\n    # TODO: implement properly\n    return a + b"
    final = auto_fix_loop(sample)
    print("Final code:\n", final)
