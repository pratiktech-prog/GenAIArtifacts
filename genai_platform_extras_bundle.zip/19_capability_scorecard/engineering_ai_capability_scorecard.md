# Engineering AI Capability Scorecard (Example)

| Capability Area | Maturity (1-5) | Description | Next Steps |
|-----------------|----------------|-------------|-----------|
| Prompt Engineering | 3 | Teams use prompts but not standardized | Roll out shared prompt libraries |
| Copilot Adoption | 4 | Widely adopted for coding tasks | Deepen usage in testing and documentation |
| RAG Usage | 2 | Limited pilots | Expand to key domains and teams |
| Governance and Policy | 3 | Initial policies in place | Formalize governance board |
| Model Evaluation | 2 | Ad-hoc bake-offs | Standardize evaluation framework |
| Platform Observability | 3 | Basic logging and dashboards | Add cost and performance SLOs |
