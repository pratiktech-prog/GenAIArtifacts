# GenAI Risk Framework for Financial Services (Concept)

| Risk Category | Example Risk | Impact Level | Mitigation | Platform Control |
|--------------|--------------|--------------|-----------|------------------|
| Data Privacy | PII leakage in prompts or logs | High | Redaction, tokenization, strict logging | AI Gateway, logging layer |
| Market Abuse | Model generating inappropriate trading signals | High | Policy filters, human review | Gateway filters, workflows |
| Hallucination | Incorrect answers for regulatory topics | Medium | RAG grounding, evaluation, disclaimers | MCP + RAG + eval hooks |
| Security | Prompt injection, exfiltration attempts | High | Input validation, allow-list tools | Gateway + app layer |
| Compliance | Region/data residency violations | High | Region-aware routing, provider selection | Gateway routing rules |
| Operational | Cost overruns from uncontrolled usage | Medium | Quotas, budgets, cost dashboards | Gateway + observability |
