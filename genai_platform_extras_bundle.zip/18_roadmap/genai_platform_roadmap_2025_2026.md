# GenAI Platform Roadmap (2025-2026)

Phase 1 - Foundation (Q1-Q2 2025)
- GitHub Copilot pilot and rollout
- Establish GenAI Guild and training curriculum
- Baseline metrics for productivity and quality

Phase 2 - Platformization (Q3-Q4 2025)
- MCP server MVP (context server)
- AI Gateway for central routing and safety
- Initial RAG for internal documentation and KBs

Phase 3 - Scale and Governance (Q1-Q2 2026)
- Multi-region support and DR for AI workloads
- Expanded RAG coverage (policies, procedures, product docs)
- Formal AI governance board and risk framework adoption

Phase 4 - Advanced Automation (Q3-Q4 2026)
- Agentic workflows for QA and support
- Semi-autonomous maintenance tasks with strong human oversight
- Integration with broader digital transformation roadmap
